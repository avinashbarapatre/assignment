﻿import { Component, OnInit } from '@angular/core';

@Component({templateUrl: 'thankyou.component.html'})
export class ThankYouComponent implements OnInit {   

    constructor() {}

    ngOnInit() {
        
    }
    
}
